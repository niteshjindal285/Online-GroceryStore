// import React, { useState } from 'react';
// import { Search, Filter, Star, Plus } from 'lucide-react';
// import { useCart } from '../contexts/CartContext';
// import { Link } from 'react-router-dom';

// const UserDashboard: React.FC = () => {
//   const [searchTerm, setSearchTerm] = useState('');
//   const [selectedCategory, setSelectedCategory] = useState('all');
//   const [sortBy, setSortBy] = useState('name');
//   const { addToCart } = useCart();

//   const categories = [
//     { id: 'all', name: 'All Products' },
//     { id: 'fruits', name: 'Fruits' },
//     { id: 'vegetables', name: 'Vegetables' },
//     { id: 'dairy', name: 'Dairy' },
//     { id: 'meat', name: 'Meat & Seafood' },
//     { id: 'bakery', name: 'Bakery' },
//     { id: 'beverages', name: 'Beverages' }
//   ];

//   const products = [
//     {
//       id: '1',
//       name: 'Chambal',
//       price: 128,
//       image: 'https://media.dealshare.in/img/offer/1751009426619:0C931BD190_1.png?tr=f-webp',
//       rating: 4.8,
//       discount: 15
//     },
//     {
//       id: '2',
//       name: 'Chambal 5L',
//       price: 665,
//       image: 'https://media.dealshare.in/img/offer/1742374265320:0A6256F2B0_1.png?tr=f-webp',
//       rating: 4.9,
//       discount: 10
//     },
//     {
//       id: '3',
//       name: 'Amul Ghee 1LK',
//       price: 577,
//       image: 'https://media.dealshare.in/img/offer/1751010093034:789AFF118B_1.png?tr=f-webp',
//       rating: 4.7,
//       discount: 20
//     },
//     {
//       id: '4',
//       name: 'Krishna Ghee 1L',
//       price: 575,
//       image: 'https://media.dealshare.in/img/offer/1751010093116:685ACFE4F3_1.png?tr=f-webp',
//       rating: 4.6,
//       discount: 5
//     },
//     {
//       id: '5',
//       name: 'Krishna Ghee 500ml',
//       price: 296,
//       image: 'https://media.dealshare.in/img/offer/1751010093116:685ACFE4F3_1.png?tr=f-webp',
//       rating: 4.6,
//       discount: 5
//     },
//     {
//       id: '6',
//       name: 'Amul Ghee 500ML',
//       price: 300,
//       image: 'https://media.dealshare.in/img/offer/1751010093034:789AFF118B_1.png?tr=f-webp',
//       rating: 4.7,
//       discount: 20
//     },
//     {
//       id: '7',
//       name: 'Saras Ghee 500ML',
//       price: 270,
//       image: 'https://media.dealshare.in/img/offer/1743008268081:D617F52F15_1.png?tr=f-webp',
//       rating: 4.7,
//       discount: 20
//     },
//     {
//       id: '8',
//       name: 'Saras Ghee 1L',
//       price: 515,
//       image: 'https://media.dealshare.in/img/offer/1743008268081:D617F52F15_1.png?tr=f-webp',
//       rating: 4.7,
//       discount: 20
//     },
//     {
//       id: '9',
//       name: 'Oswal Soap',
//       price: 84,
//       image: 'https://media.dealshare.in/img/offer/1751011291631:C89837D20A_1.png?tr=f-webp',
//       rating: 4.7,
//       discount: 20
//     },
//     {
//       id: '10',
//       name: 'Taaza Tea 1KG',
//       price: 189,
//       image: 'https://media.dealshare.in/img/offer/1742374266672:642868CAF9_1.png?tr=f-webp',
//       rating: 4.7,
//       discount: 20
//     },
//     {
//       id: '11',
//       name: 'Taaza Tea 250GG',
//       price: 57,
//       image: 'https://media.dealshare.in/img/offer/1742374266672:642868CAF9_1.png?tr=f-webp',
//       rating: 4.7,
//       discount: 20
//     }
//   ];


//   const filteredProducts = products.filter(product => {
//     const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase());
//     const matchesCategory = selectedCategory === 'all' || product.category === selectedCategory;
//     return matchesSearch && matchesCategory;
//   });

//   const sortedProducts = [...filteredProducts].sort((a, b) => {
//     switch (sortBy) {
//       case 'price-low':
//         return a.price - b.price;
//       case 'price-high':
//         return b.price - a.price;
//       case 'rating':
//         return b.rating - a.rating;
//       default:
//         return a.name.localeCompare(b.name);
//     }
//   });

//   const handleAddToCart = (product: any) => {
//     addToCart({
//       id: product.id,
//       name: product.name,
//       price: product.price,
//       image: product.image,
//       category: product.category
//     });
//   };

//   return (
//     <div className="min-h-screen bg-gray-50">
//       <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
//         {/* Header */}
//         <div className="mb-8">
//           <h1 className="text-3xl font-bold text-gray-900 mb-2">Product Catalog</h1>
//           <p className="text-gray-600">Discover fresh products for your daily needs</p>
//         </div>

//         {/* Search and Filters */}
//         <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
//           <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
//             {/* Search */}
//             <div className="relative">
//               <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
//               <input
//                 type="text"
//                 placeholder="Search products..."
//                 value={searchTerm}
//                 onChange={(e) => setSearchTerm(e.target.value)}
//                 className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
//               />
//             </div>

//             {/* Category Filter */}
//             <div className="relative">
//               <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
//               <select
//                 value={selectedCategory}
//                 onChange={(e) => setSelectedCategory(e.target.value)}
//                 className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent appearance-none"
//               >
//                 {categories.map(category => (
//                   <option key={category.id} value={category.id}>
//                     {category.name}
//                   </option>
//                 ))}
//               </select>
//             </div>

//             {/* Sort */}
//             <div>
//               <select
//                 value={sortBy}
//                 onChange={(e) => setSortBy(e.target.value)}
//                 className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent appearance-none"
//               >
//                 <option value="name">Sort by Name</option>
//                 <option value="price-low">Price: Low to High</option>
//                 <option value="price-high">Price: High to Low</option>
//                 <option value="rating">Highest Rated</option>
//               </select>
//             </div>
//           </div>
//         </div>

//         {/* Products Grid */}
//         <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
//           {sortedProducts.map(product => (
//             <div key={product.id} className="bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow duration-200 overflow-hidden">
//               <div className="aspect-w-1 aspect-h-1">
//                 <img
//                   src={product.image}
//                   alt={product.name}
//                   className="w-full h-48 object-cover hover:scale-105 transition-transform duration-200"
//                 />
//               </div>
//               <div className="p-4">
//                 <h3 className="font-semibold text-gray-900 mb-2">{product.name}</h3>
//                 <p className="text-sm text-gray-600 mb-3 line-clamp-2">{product.description}</p>
                
//                 <div className="flex items-center mb-3">
//                   <Star className="h-4 w-4 text-yellow-400 fill-current" />
//                   <span className="text-sm text-gray-600 ml-1">{product.rating}</span>
//                   <span className={`ml-auto text-sm px-2 py-1 rounded-full ${
//                     product.inStock ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
//                   }`}>
//                     {product.inStock ? 'In Stock' : 'Out of Stock'}
//                   </span>
//                 </div>
                
//                 <div className="flex items-center justify-between">
//                   <span className="text-lg font-bold text-emerald-600">${product.price}</span>
//                   <div className="flex space-x-2">
//                     <Link
//                       to={`/products/${product.id}`}
//                       className="px-3 py-1 text-sm border border-emerald-600 text-emerald-600 rounded-md hover:bg-emerald-50 transition-colors duration-200"
//                     >
//                       View
//                     </Link>
//                     <button
//                       onClick={() => handleAddToCart(product)}
//                       disabled={!product.inStock}
//                       className="px-3 py-1 text-sm bg-emerald-600 text-white rounded-md hover:bg-emerald-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors duration-200 flex items-center"
//                     >
//                       <Plus className="h-4 w-4 mr-1" />
//                       Add
//                     </button>
//                   </div>
//                 </div>
//               </div>
//             </div>
//           ))}
//         </div>

//         {filteredProducts.length === 0 && (
//           <div className="text-center py-12">
//             <p className="text-gray-500 text-lg">No products found matching your criteria.</p>
//           </div>
//         )}
//       </div>
//     </div>
//   );
// };

// export default UserDashboard;



import React, { useState } from "react";
import { Search, Filter, Star, Plus } from "lucide-react";
import { useCart } from "../contexts/CartContext";
import { Link } from "react-router-dom";

const UserDashboard: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [sortBy, setSortBy] = useState("name");
  const { addToCart } = useCart();

  const categories = [
    { id: "all", name: "All Products" },
    { id: "dairy", name: "Dairy" },
    { id: "fruits", name: "Fruits" },
    { id: "vegetables", name: "Vegetables" },
    { id: "beverages", name: "Beverages" },
    { id: "bakery", name: "Bakery" },
    { id: "grocery", name: "Grocery" },
  ];

  // ✅ Added category + inStock for each
  const products = [
    {
      id: "1",
      name: "Chambal",
      price: 128,
      category: "grocery",
      image:
        "https://media.dealshare.in/img/offer/1751009426619:0C931BD190_1.png?tr=f-webp",
      rating: 4.8,
      discount: 15,
      inStock: true,
    },
    {
      id: "2",
      name: "Chambal 5L",
      price: 665,
      category: "grocery",
      image:
        "https://media.dealshare.in/img/offer/1742374265320:0A6256F2B0_1.png?tr=f-webp",
      rating: 4.9,
      discount: 10,
      inStock: true,
    },
    {
      id: "3",
      name: "Amul Ghee 1L",
      price: 577,
      category: "dairy",
      image:
        "https://media.dealshare.in/img/offer/1751010093034:789AFF118B_1.png?tr=f-webp",
      rating: 4.7,
      discount: 20,
      inStock: true,
    },
    {
      id: "4",
      name: "Krishna Ghee 1L",
      price: 575,
      category: "dairy",
      image:
        "https://media.dealshare.in/img/offer/1751010093116:685ACFE4F3_1.png?tr=f-webp",
      rating: 4.6,
      discount: 5,
      inStock: true,
    },
    {
      id: "5",
      name: "Krishna Ghee 500ml",
      price: 296,
      category: "dairy",
      image:
        "https://media.dealshare.in/img/offer/1751010093116:685ACFE4F3_1.png?tr=f-webp",
      rating: 4.6,
      discount: 5,
      inStock: true,
    },
    {
      id: "6",
      name: "Amul Ghee 500ml",
      price: 300,
      category: "dairy",
      image:
        "https://media.dealshare.in/img/offer/1751010093034:789AFF118B_1.png?tr=f-webp",
      rating: 4.7,
      discount: 20,
      inStock: true,
    },
    {
      id: "7",
      name: "Saras Ghee 500ml",
      price: 270,
      category: "dairy",
      image:
        "https://media.dealshare.in/img/offer/1743008268081:D617F52F15_1.png?tr=f-webp",
      rating: 4.7,
      discount: 20,
      inStock: true,
    },
    {
      id: "8",
      name: "Saras Ghee 1L",
      price: 515,
      category: "dairy",
      image:
        "https://media.dealshare.in/img/offer/1743008268081:D617F52F15_1.png?tr=f-webp",
      rating: 4.7,
      discount: 20,
      inStock: true,
    },
    {
      id: "9",
      name: "Oswal Soap",
      price: 84,
      category: "grocery",
      image:
        "https://media.dealshare.in/img/offer/1751011291631:C89837D20A_1.png?tr=f-webp",
      rating: 4.7,
      discount: 20,
      inStock: true,
    },
    {
      id: "10",
      name: "Taaza Tea 1KG",
      price: 189,
      category: "beverages",
      image:
        "https://media.dealshare.in/img/offer/1742374266672:642868CAF9_1.png?tr=f-webp",
      rating: 4.7,
      discount: 20,
      inStock: true,
    },
    {
      id: "11",
      name: "Taaza Tea 250g",
      price: 57,
      category: "beverages",
      image:
        "https://media.dealshare.in/img/offer/1742374266672:642868CAF9_1.png?tr=f-webp",
      rating: 4.7,
      discount: 20,
      inStock: true,
    },

    {
      id: "12",
      name: "Tata Premium Tea - 1 Kg",
      price: 489,
      category: "beverages",
      image:
        "https://media.dealshare.in/img/offer/1751011291220:873D476C94_1.png?tr=f-webp",
      rating: 4.7,
      discount: 20,
      inStock: true,
    },
    {
      id: "13",
      name: "Horlicks Chocolate Jar - 1 Kg",
      price:  349,
      category: "beverages",
      image:
        "https://media.dealshare.in/img/offer/1751009426532:0B2DAFD45F_1.png?tr=f-webp",
      rating: 4.7,
      discount: 20,
      inStock: true,
    },
    {
      id: "14",
      name: "Laxmi Bhog Atta - 10 Kg",
      price:  399,
      category: "grocery",
      image:
        "https://media.dealshare.in/img/offer/1751010093129:4855D2F2E0_1.png?tr=f-webp",
      rating: 4.7,
      discount: 20,
      inStock: true,
    },
    {
      id: "15",
      name: "Laxmi Bhog Atta - 5 Kg",
      price:  202,
      category: "grocery",
      image:
        "https://media.dealshare.in/img/offer/1751010093129:4855D2F2E0_1.png?tr=f-webp",
      rating: 4.7,
      discount: 20,
      inStock: true,
    },
    {
      id: "16",
      name: "Laxmi Bhog Suji - 1 Kg",
      price:  50,
      category: "grocery",
      image:
        "https://media.dealshare.in/img/offer/1741596846075:8C374CA701_1.png",
      rating: 4.7,
      discount: 20,
      inStock: true,
    },
    {
      id: "17",
      name: "Laxmi Bhog Suji - 500 gm",
      price:  28,
      category: "grocery",
      image:
        "https://media.dealshare.in/img/offer/1741596846075:8C374CA701_1.png",
      rating: 4.7,
      discount: 20,
      inStock: true,
    },
    {
      id: "18",
      name: "Laxmi Bhog Madia - 500 gm",
      price:  25,
      category: "grocery",
      image:
        "https://media.dealshare.in/img/offer/1742210634663:103DBD5C59_1.png?tr=f-webp",
      rating: 4.7,
      discount: 20,
      inStock: true,
    },
    {
      id: "19",
      name: "Laxmi Bhog Madia - 1 kg",
      price:  50,
      category: "grocery",
      image:
        "https://media.dealshare.in/img/offer/1742210634663:103DBD5C59_1.png?tr=f-webp",
      rating: 4.7,
      discount: 20,
      inStock: true,
    },
    {
      id: "20",
      name: "Laxmi Bhog Basen -500 Gm",
      price:  50,
      category: "grocery",
      image:
        "https://media.dealshare.in/img/offer/A3D32C36E2_1.webp?tr=f-webp",
      rating: 4.7,
      discount: 20,
      inStock: true,
    },
    {
      id: "21",
      name: "Laxmi Bhog Basen -1Kg",
      price:  95,
      category: "grocery",
      image:
        "https://media.dealshare.in/img/offer/A3D32C36E2_1.webp?tr=f-webp",
      rating: 4.7,
      discount: 20,
      inStock: true,
    },
    {
      id: "22",
      name: "Laxmi Bhog Dalia -1Kg",
      price:  62,
      category: "grocery",
      image:
        "https://images.dealshare.in/1754456901237:67B545507D_1.png?tr=f-webp",
      rating: 4.7,
      discount: 20,
      inStock: true,
    },
    {
      id: "23",
      name: "Laxmi Bhog Dalia -1Kg",
      price:  32,
      category: "grocery",
      image:
        "https://images.dealshare.in/1754456901237:67B545507D_1.png?tr=f-webp",
      rating: 4.7,
      discount: 20,
      inStock: true,
    },
    {
      id: "24",
      name: "Fortune Mogra Basmati Rice - 5 Kg",
      price:  312,
      category: "grocery",
      image:
        "https://media.dealshare.in/img/offer/F870A3D320_1.webp?tr=f-webp",
      rating: 4.7,
      discount: 20,
      inStock: true,
    },
    {
      id: "25",
      name: "Fortune Mogra Basmati Rice - 10 Kg",
      price:  612,
      category: "grocery",
      image:
        "https://media.dealshare.in/img/offer/F870A3D320_1.webp?tr=f-webp",
      rating: 4.7,
      discount: 20,
      inStock: true,
    },
    {
      id: "26",
      name: "Fortune Mini Mogra Basmati Rice - 5 Kg",
      price:  271,
      category: "grocery",
      image:
        "https://images.dealshare.in/1753957333960:F7BFF5F2FD_1.png?tr=f-webp",
      rating: 4.7,
      discount: 20,
      inStock: true,
    },
    {
      id: "27",
      name: "Fortune Mini Mogra Basmati Rice - 10 Kg",
      price:  550,
      category: "grocery",
      image:
        "https://images.dealshare.in/1753957333960:F7BFF5F2FD_1.png?tr=f-webp",
      rating: 4.7,
      discount: 20,
      inStock: true,
    },
    {
      id: "28",
      name: "Fortune Rice Bran Health Oil (pouch) - 825 Gm",
      price:  157,
      category: "grocery",
      image:
        "https://images.dealshare.in/1761135461094:B876140DED_1.png?tr=f-webp",
      rating: 4.7,
      discount: 20,
      inStock: true,
    },
    {
      id: "29",
      name: "Fortune Sunlite Refined Sunflower Oil - 4.35 Kg",
      price:  825,
      category: "grocery",
      image:
        "https://media.dealshare.in/img/offer/1746535993492:98F2096C64_1.png?tr=f-webp",
      rating: 4.7,
      discount: 20,
      inStock: true,
    },
    {
      id: "30",
      name: "Fortune Rozana Gold Basmati Rice - 1 Kg",
      price:  89,
      category: "grocery",
      image:
        "https://images.dealshare.in/1753957336146:YC8525AAA2_1.png?tr=f-webp",
      rating: 4.7,
      discount: 20,
      inStock: true,
    },
    {
      id: "31",
      name: "Fortune Sun Lite Refined Sunflower Oil - 800 Gm",
      price:  162,
      category: "grocery",
      image:
        "https://media.dealshare.in/img/offer/1745846109567:B11DBC1F33_1.png?tr=f-webp",
      rating: 4.7,
      discount: 20,
      inStock: true,
    },
    {
      id: "32",
      name: "Fortune Filtered Groundnut Oil - 870 Gm",
      price:  173,
      category: "grocery",
      image:
        "https://media.dealshare.in/img/offer/1738240174680:FE8CD2DFBA_1.webp?tr=f-webp",
      rating: 4.7,
      discount: 20,
      inStock: true,
    },
    {
      id: "33",
      name: "Fortune Rozana Gold Basmati Rice - 5 Kg",
      price:  424,
      category: "grocery",
      image:
        "https://images.dealshare.in/1753957336146:YC8525AAA2_1.png?tr=f-webp",
      rating: 4.7,
      discount: 20,
      inStock: true,
    },
    {
      id: "34",
      name: "Fortune Rice Bran Health Oil (Jar) - 4.35 Kg",
      price:  806,
      category: "grocery",
      image:
        "https://media.dealshare.in/img/offer/1743833707913:51E3B2B0FD_1.png?tr=f-webp",
      rating: 4.7,
      discount: 20,
      inStock: true,
    },
    {
      id: "35",
      name: "Fortune Filtered Groundnut Oil - 4.35 Kg",
      price:  985,
      category: "grocery",
      image:
        "https://media.dealshare.in/img/offer/1724683332136:190A21737F_1.webp?tr=f-webp",
      rating: 4.7,
      discount: 20,
      inStock: true,
    },
    {
      id: "36",
      name: "Fortune Chakki Fresh Atta - 10 Kg",
      price:  410,
      category: "grocery",
      image:
        "https://media.dealshare.in/img/offer/1742900595676:4C1C32FFD0_1.png?tr=f-webp",
      rating: 4.7,
      discount: 20,
      inStock: true,
    },
    {
      id: "37",
      name: "Fortune Rozana Super Basmati Rice - 1 Kg",
      price:  65,
      category: "grocery",
      image:
        "https://images.dealshare.in/1753957333960:D55801E0DE_1.png?tr=f-webp",
      rating: 4.7,
      discount: 20,
      inStock: true,
    },
    {
      id: "38",
      name: "Fortune Rozana Super Basmati Rice - 5 Kg",
      price:  312,
      category: "grocery",
      image:
        "https://images.dealshare.in/1753957333960:D55801E0DE_1.png?tr=f-webp",
      rating: 4.7,
      discount: 20,
      inStock: true,
    },
    {
      id: "39",
      name: "Fortune Refined Soyabean Oil - 4.35 Kg",
      price:  775,
      category: "grocery",
      image:
        "https://media.dealshare.in/img/offer/1751011292010:DCC51871CA_1.png?tr=f-webp",
      rating: 4.7,
      discount: 20,
      inStock: true,
    },
    {
      id: "40",
      name: "Fortune Chakki Fresh Atta - 5 Kg",
      price:  225,
      category: "grocery",
      image:
        "https://media.dealshare.in/img/offer/1742900595676:4C1C32FFD0_1.png?tr=f-webp",
      rating: 4.7,
      discount: 20,
      inStock: true,
    },
    {
      id: "41",
      name: "Fortune Biryani Special Basmati Rice - 1 Kg",
      price:  177,
      category: "grocery",
      image:
        "https://images.dealshare.in/1753957333066:5066BCD15C_1.png?tr=f-webp",
      rating: 4.7,
      discount: 20,
      inStock: true,
    },
    {
      id: "42",
      name: "Tata Agni Tea - 1 Kg",
      price:  215,
      category: "beverages",
      image:
        "https://media.dealshare.in/img/offer/1751011291023:8E6B56F8A4_1.png?tr=f-webp",
      rating: 4.7,
      discount: 20,
      inStock: true,
    },
    {
      id: "43",
      name: "Tata Agni Elaich i Tea - 250 Gm",
      price:  90,
      category: "beverages",
      image:
        "https://media.dealshare.in/img/offer/18F84CBFC3_1.webp?tr=f-webp",
      rating: 4.7,
      discount: 20,
      inStock: true,
    },
    {
      id: "44",
      name: "Tata Tea Agni - 1.5 Kg",
      price:  270,
      category: "beverages",
      image:
        "https://media.dealshare.in/img/offer/1751011291018:8FA29DE506_1.png?tr=f-webp",
      rating: 4.7,
      discount: 20,
      inStock: true,
    },
    {
      id: "45",
      name: "Tata Tea Agni Elaichi Chai - 1 Kg",
      price:  301,
      category: "beverages",
      image:
        "https://images.dealshare.in/175749485302300978B3B6F_1.png?tr=f-webp",
      rating: 4.7,
      discount: 20,
      inStock: true,
    },
    {
      id: "46",
      name: "Tata Agni Tea - 250 Gm",
      price:  55,
      category: "beverages",
      image:
        "https://media.dealshare.in/img/offer/1726636263702:6BA1F7CE61_1.webp?tr=f-webp",
      rating: 4.7,
      discount: 20,
      inStock: true,
    },
    {
      id: "47",
      name: "Cadbury Bournvita Chocolate (Pouch) - 1 Kg",
      price:  337,
      category: "beverages",
      image:
        "https://media.dealshare.in/img/offer/1751009429403:3BAE09ED52_1.png?tr=f-webp",
      rating: 4.7,
      discount: 20,
      inStock: true,
    },
    {
      id: "48",
      name: "Tata Tea Gold - 500 Gm",
      price:  282,
      category: "beverages",
      image:
        "https://media.dealshare.in/img/offer/71AFB1D215_1.webp?tr=f-webp",
      rating: 4.7,
      discount: 20,
      inStock: true,
    },
    {
      id: "49",
      name: "Red Label Tea - 1 Kg",
      price:  419,
      category: "beverages",
      image:
        "https://media.dealshare.in/img/offer/1751009429421:04E0C7F3D1_1.png?tr=f-webp",
      rating: 4.7,
      discount: 20,
      inStock: true,
    },
    {
      id: "50",
      name: "Surf Excel Easy Wash Detergent Powder - 7 Kg",
      price:  665,
      category: "beverages",
      image:
        "https://media.dealshare.in/img/offer/1751011292213:EDDA0E0DEC_1.png?tr=f-webp",
      rating: 4.7,
      discount: 20,
      inStock: true,
    },
  ];

  // ✅ Filter and sort logic
  const filteredProducts = products.filter((product) => {
    const matchesSearch = product.name
      .toLowerCase()
      .includes(searchTerm.toLowerCase());
    const matchesCategory =
      selectedCategory === "all" || product.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const sortedProducts = [...filteredProducts].sort((a, b) => {
    switch (sortBy) {
      case "price-low":
        return a.price - b.price;
      case "price-high":
        return b.price - a.price;
      case "rating":
        return b.rating - a.rating;
      default:
        return a.name.localeCompare(b.name);
    }
  });

  const handleAddToCart = (product: any) => {
    addToCart({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      category: product.category,
    });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Product Catalog
          </h1>
          <p className="text-gray-600">
            Discover fresh products for your daily needs
          </p>
        </div>

        {/* Search and Filters */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Search */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
              <input
                type="text"
                placeholder="Search products..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
              />
            </div>

            {/* Category Filter */}
            <div className="relative">
              <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent appearance-none"
              >
                {categories.map((category) => (
                  <option key={category.id} value={category.id}>
                    {category.name}
                  </option>
                ))}
              </select>
            </div>

            {/* Sort */}
            <div>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent appearance-none"
              >
                <option value="name">Sort by Name</option>
                <option value="price-low">Price: Low to High</option>
                <option value="price-high">Price: High to Low</option>
                <option value="rating">Highest Rated</option>
              </select>
            </div>
          </div>
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {sortedProducts.map((product) => (
            <div
              key={product.id}
              className="bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow duration-200 overflow-hidden"
            >
              <div className="aspect-w-1 aspect-h-1">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-48 object-cover hover:scale-105 transition-transform duration-200"
                />
              </div>
              <div className="p-4">
                <h3 className="font-semibold text-gray-900 mb-2">
                  {product.name}
                </h3>

                <div className="flex items-center mb-3">
                  <Star className="h-4 w-4 text-yellow-400 fill-current" />
                  <span className="text-sm text-gray-600 ml-1">
                    {product.rating}
                  </span>
                  <span
                    className={`ml-auto text-sm px-2 py-1 rounded-full ${
                      product.inStock
                        ? "bg-green-100 text-green-800"
                        : "bg-red-100 text-red-800"
                    }`}
                  >
                    {product.inStock ? "In Stock" : "Out of Stock"}
                  </span>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-lg font-bold text-emerald-600">
                    ₹{product.price}
                  </span>
                  <div className="flex space-x-2">
                    <Link
                      to={`/products/${product.id}`}
                      state={{ product }} // ✅ Send full product data
                      className="px-3 py-1 text-sm border border-emerald-600 text-emerald-600 rounded-md hover:bg-emerald-50 transition-colors duration-200"
                    >
                      View
                    </Link>
                    <button
                      onClick={() => handleAddToCart(product)}
                      disabled={!product.inStock}
                      className="px-3 py-1 text-sm bg-emerald-600 text-white rounded-md hover:bg-emerald-700 disabled:opacity-50 flex items-center transition-colors duration-200"
                    >
                      <Plus className="h-4 w-4 mr-1" />
                      Add
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {filteredProducts.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-500 text-lg">
              No products found matching your criteria.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default UserDashboard;
