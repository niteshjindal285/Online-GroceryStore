import React from 'react';
import { Link } from 'react-router-dom';
import { Home, ArrowLeft, Search, MapPin } from 'lucide-react';

const NotFoundPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center">
      <div className="max-w-md w-full text-center px-4">
        {/* 404 Illustration */}
        <div className="mb-8">
          <div className="relative">
            <div className="text-8xl font-bold text-emerald-200 mb-4">404</div>
            <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
              <div className="bg-emerald-600 text-white p-4 rounded-full">
                <MapPin className="h-8 w-8" />
              </div>
            </div>
          </div>
        </div>

        {/* Error Message */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">
            Oops! Page Not Found
          </h1>
          <p className="text-gray-600 text-lg mb-6">
            The page you're looking for seems to have gone on a delivery run. 
            Don't worry, we'll help you find what you need!
          </p>
        </div>

        {/* Action Buttons */}
        <div className="space-y-4">
          <Link
            to="/"
            className="w-full bg-emerald-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-emerald-700 transition-colors duration-200 flex items-center justify-center"
          >
            <Home className="h-5 w-5 mr-2" />
            Go to Homepage
          </Link>
          
          <Link
            to="/dashboard"
            className="w-full border-2 border-emerald-600 text-emerald-600 px-6 py-3 rounded-lg font-semibold hover:bg-emerald-50 transition-colors duration-200 flex items-center justify-center"
          >
            <Search className="h-5 w-5 mr-2" />
            Browse Products
          </Link>
          
          <button
            onClick={() => window.history.back()}
            className="w-full text-gray-600 hover:text-gray-800 px-6 py-3 rounded-lg font-semibold transition-colors duration-200 flex items-center justify-center"
          >
            <ArrowLeft className="h-5 w-5 mr-2" />
            Go Back
          </button>
        </div>

        {/* Quick Links */}
        <div className="mt-12 pt-8 border-t border-gray-200">
          <p className="text-gray-500 text-sm mb-4">Looking for something specific?</p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link
              to="/about"
              className="text-emerald-600 hover:text-emerald-700 text-sm transition-colors duration-200"
            >
              About Us
            </Link>
            <Link
              to="/contact"
              className="text-emerald-600 hover:text-emerald-700 text-sm transition-colors duration-200"
            >
              Contact
            </Link>
            <Link
              to="/login"
              className="text-emerald-600 hover:text-emerald-700 text-sm transition-colors duration-200"
            >
              Login
            </Link>
            <Link
              to="/signup"
              className="text-emerald-600 hover:text-emerald-700 text-sm transition-colors duration-200"
            >
              Sign Up
            </Link>
          </div>
        </div>

        {/* Fun Message */}
        <div className="mt-8 bg-emerald-50 border border-emerald-200 rounded-lg p-4">
          <p className="text-emerald-800 text-sm">
            <strong>Fun Fact:</strong> While you're here, did you know we deliver fresh groceries in under 30 minutes? 
            Try our service today!
          </p>
        </div>
      </div>
    </div>
  );
};

export default NotFoundPage;