// import React from 'react';
// import { Link } from 'react-router-dom';
// import { ArrowRight, Star, Clock, Truck, Shield } from 'lucide-react';
// import { useAuth } from '../contexts/AuthContext';

// const HomePage: React.FC = () => {
//   const { user } = useAuth();

//   const categories = [
//     {
//       name: 'Variety spices and herbs',
//       image: 'https://as2.ftcdn.net/v2/jpg/02/89/44/67/1000_F_289446727_vRX6ctHc8dkaeT0zcKnHSu2w5TWOVtJH.jpg',
//       count: '120+ Items'
//     },
//     {
//       name: 'Cooking Oil',
//       image: 'https://images.dealshare.in/1757134648956CookingOil.png?tr=f-webp',
//       count: '95+ Items'
//     },
//     {
//       name: 'Sugar, Salt & Jaggery',
//       image: 'https://images.dealshare.in/1757134885382Sugar,Salt&Jaggery.png?tr=f-webp',
//       count: '80+ Items'
//     },
//     {
//       name: 'Flours & Grains',
//       image: 'https://images.dealshare.in/1757134734804Flours&Grains.png?tr=f-webp',
//       count: '65+ Items'
//     },
//     {
//       name: 'Rice & Rice Products',
//       image: 'https://images.dealshare.in/1757134867440Rice&RiceProducts.png?tr=f-webp',
//       count: '45+ Items'
//     },
//     {
//       name: 'Dals & Pulses',
//       image: 'https://images.dealshare.in/1757134671179Dals&Pulses.png?tr=f-webp',
//       count: '85+ Items'
//     },
//     {
//       name: 'Ghee & Vanaspati',
//       image: 'https://images.dealshare.in/1757072788411Ghee&Vanaspati.png?tr=f-webp',
//       count: '85+ Items'
//     },
//     {
//       name: 'Dry Fruits & Nuts',
//       image: 'https://images.dealshare.in/1757134697555DryFruits.png?tr=f-webp',
//       count: '85+ Items'
//     }
//   ];

//   const featuredProducts = [
//     {
  //     id: '1',
  //     name: 'Chambal',
  //     price: 128,
  //     image: 'https://media.dealshare.in/img/offer/1751009426619:0C931BD190_1.png?tr=f-webp',
  //     rating: 4.8,
  //     discount: 15
  //   },
  //   {
  //     id: '2',
  //     name: 'Chambal 5L',
  //     price: 665,
  //     image: 'https://media.dealshare.in/img/offer/1742374265320:0A6256F2B0_1.png?tr=f-webp',
  //     rating: 4.9,
  //     discount: 10
  //   },
  //   {
  //     id: '3',
  //     name: 'Amul Ghee 1LK',
  //     price: 577,
  //     image: 'https://media.dealshare.in/img/offer/1751010093034:789AFF118B_1.png?tr=f-webp',
  //     rating: 4.7,
  //     discount: 20
  //   },
  //   {
  //     id: '4',
  //     name: 'Krishna Ghee 1L',
  //     price: 575,
  //     image: 'https://media.dealshare.in/img/offer/1751010093116:685ACFE4F3_1.png?tr=f-webp',
  //     rating: 4.6,
  //     discount: 5
  //   },
  //   {
  //     id: '5',
  //     name: 'Krishna Ghee 500ml',
  //     price: 296,
  //     image: 'https://media.dealshare.in/img/offer/1751010093116:685ACFE4F3_1.png?tr=f-webp',
  //     rating: 4.6,
  //     discount: 5
  //   },
  //   {
  //     id: '6',
  //     name: 'Amul Ghee 500ML',
  //     price: 300,
  //     image: 'https://media.dealshare.in/img/offer/1751010093034:789AFF118B_1.png?tr=f-webp',
  //     rating: 4.7,
  //     discount: 20
  //   },
  //   {
  //     id: '7',
  //     name: 'Saras Ghee 500ML',
  //     price: 270,
  //     image: 'https://media.dealshare.in/img/offer/1743008268081:D617F52F15_1.png?tr=f-webp',
  //     rating: 4.7,
  //     discount: 20
  //   },
  //   {
  //     id: '8',
  //     name: 'Saras Ghee 1L',
  //     price: 515,
  //     image: 'https://media.dealshare.in/img/offer/1743008268081:D617F52F15_1.png?tr=f-webp',
  //     rating: 4.7,
  //     discount: 20
  //   },
  //   {
  //     id: '9',
  //     name: 'Oswal Soap',
  //     price: 84,
  //     image: 'https://media.dealshare.in/img/offer/1751011291631:C89837D20A_1.png?tr=f-webp',
  //     rating: 4.7,
  //     discount: 20
  //   },
  //   {
  //     id: '10',
  //     name: 'Taaza Tea 1KG',
  //     price: 189,
  //     image: 'https://media.dealshare.in/img/offer/1742374266672:642868CAF9_1.png?tr=f-webp',
  //     rating: 4.7,
  //     discount: 20
  //   },
  //   {
  //     id: '11',
  //     name: 'Taaza Tea 250GG',
  //     price: 57,
  //     image: 'https://media.dealshare.in/img/offer/1742374266672:642868CAF9_1.png?tr=f-webp',
  //     rating: 4.7,
  //     discount: 20
  //   }
  // ];

//   const features = [
//     {
//       icon: <Clock className="h-6 w-6" />,
//       title: 'Fast Delivery',
//       description: 'Get your groceries delivered within 30 minutes'
//     },
//     {
//       icon: <Shield className="h-6 w-6" />,
//       title: 'Quality Guaranteed',
//       description: 'Fresh products with 100% quality assurance'
//     },
//     {
//       icon: <Truck className="h-6 w-6" />,
//       title: 'Free Delivery',
//       description: 'Free delivery on orders above $50'
//     }
//   ];

//   return (
//     <div className="min-h-screen">
//       {/* Hero Section */}
//       <section className="relative bg-gradient-to-r from-emerald-600 via-emerald-700 to-emerald-800 text-white">
//         <div className="absolute inset-0 bg-black opacity-10"></div>
//         <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
//           <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
//             <div className="space-y-6">
//               <h1 className="text-4xl md:text-6xl font-bold leading-tight">
//                 Fresh Groceries
//                 <span className="text-orange-400"> Delivered</span>
//                 <br />To Your Door
//               </h1>
//               <p className="text-xl text-emerald-100 max-w-lg">
//                 Get the freshest groceries and food items delivered to your doorstep in minutes.
//                 Quality guaranteed, prices you'll love.
//               </p>
//               <div className="flex flex-col sm:flex-row gap-4">
//                 {!user ? (
//                   <>
//                     <Link
//                       to="/signup"
//                       className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-3 rounded-lg font-semibold transition-colors duration-200 flex items-center justify-center"
//                     >
//                       Get Started
//                       <ArrowRight className="ml-2 h-5 w-5" />
//                     </Link>
//                     <Link
//                       to="/dashboard"
//                       className="border-2 border-white text-white hover:bg-white hover:text-emerald-600 px-8 py-3 rounded-lg font-semibold transition-colors duration-200 flex items-center justify-center"
//                     >
//                       Browse Products
//                     </Link>
//                   </>
//                 ) : (
//                   <Link
//                     to="/dashboard"
//                     className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-3 rounded-lg font-semibold transition-colors duration-200 flex items-center justify-center"
//                   >
//                     Start Shopping
//                     <ArrowRight className="ml-2 h-5 w-5" />
//                   </Link>
//                 )}
//               </div>
//             </div>
//             <div className="relative">
//               <img
//                 src="https://as1.ftcdn.net/v2/jpg/16/29/70/80/1000_F_1629708072_5C2KrBU5mrGky8kKFB3Ro96MN06sNQmy.jpg"
//                 alt="Fresh groceries"
//                 className="rounded-2xl shadow-2xl"
//               />
//             </div>
//           </div>
//         </div>
//       </section>

//       {/* Features Section */}
//       <section className="py-16 bg-white">
//         <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
//           <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
//             {features.map((feature, index) => (
//               <div key={index} className="text-center space-y-4">
//                 <div className="bg-emerald-100 text-emerald-600 w-16 h-16 rounded-full flex items-center justify-center mx-auto">
//                   {feature.icon}
//                 </div>
//                 <h3 className="text-xl font-semibold text-gray-900">{feature.title}</h3>
//                 <p className="text-gray-600">{feature.description}</p>
//               </div>
//             ))}
//           </div>
//         </div>
//       </section>

//       {/* Categories Section */}
//       <section className="py-16 bg-gray-50">
//         <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
//           <div className="text-center mb-12">
//             <h2 className="text-3xl font-bold text-gray-900 mb-4">Shop by Category</h2>
//             <p className="text-gray-600 max-w-2xl mx-auto">
//               Discover our wide range of fresh products across different categories
//             </p>
//           </div>

//           <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
//             {categories.map((category, index) => (
//               <Link
//                 key={index}
//                 to="/dashboard"
//                 className="group bg-white rounded-xl p-6 shadow-sm hover:shadow-md transition-shadow duration-200"
//               >
//                 <div className="aspect-w-1 aspect-h-1 mb-4">
//                   <img
//                     src={category.image}
//                     alt={category.name}
//                     className="w-full h-24 object-cover rounded-lg group-hover:scale-105 transition-transform duration-200"
//                   />
//                 </div>
//                 <h3 className="font-semibold text-gray-900 text-center">{category.name}</h3>
//                 <p className="text-sm text-gray-500 text-center mt-1">{category.count}</p>
//               </Link>
//             ))}
//           </div>
//         </div>
//       </section>

//       {/* Featured Products Section */}
//       <section className="py-16 bg-white">
//         <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
//           <div className="text-center mb-12">
//             <h2 className="text-3xl font-bold text-gray-900 mb-4">Featured Products</h2>
//             <p className="text-gray-600 max-w-2xl mx-auto">
//               Handpicked products with the best quality and prices
//             </p>
//           </div>

//           <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
//             {featuredProducts.map((product) => (
//               <div key={product.id} className="group bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow duration-200 overflow-hidden">
//                 <div className="relative">
//                   <img
//                     src={product.image}
//                     alt={product.name}
//                     className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-200"
//                   />
//                   {product.discount > 0 && (
//                     <span className="absolute top-2 left-2 bg-orange-500 text-white px-2 py-1 rounded-md text-sm font-semibold">
//                       {product.discount}% OFF
//                     </span>
//                   )}
//                 </div>
//                 <div className="p-4">
//                   <h3 className="font-semibold text-gray-900 mb-2">{product.name}</h3>
//                   <div className="flex items-center mb-2">
//                     <Star className="h-4 w-4 text-yellow-400 fill-current" />
//                     <span className="text-sm text-gray-600 ml-1">{product.rating}</span>
//                   </div>
//                   <div className="flex items-center justify-between">
//                     <span className="text-lg font-bold text-emerald-600">${product.price}</span>
//                     <Link
//                       to={`/products/${product.id}`}
//                       className="bg-emerald-600 text-white px-4 py-2 rounded-lg hover:bg-emerald-700 transition-colors duration-200"
//                     >
//                       Add to Cart
//                     </Link>
//                   </div>
//                 </div>
//               </div>
//             ))}
//           </div>
//         </div>
//       </section>

//       {/* CTA Section */}
//       <section className="py-16 bg-emerald-600 text-white">
//         <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
//           <h2 className="text-3xl font-bold mb-4">Ready to Start Shopping?</h2>
//           <p className="text-emerald-100 text-lg mb-8 max-w-2xl mx-auto">
//             Join thousands of satisfied customers who trust StoreToDoor for their grocery needs
//           </p>
//           {!user ? (
//             <div className="flex flex-col sm:flex-row gap-4 justify-center">
//               <Link
//                 to="/signup"
//                 className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-3 rounded-lg font-semibold transition-colors duration-200"
//               >
//                 Sign Up Now
//               </Link>
//               <Link
//                 to="/login"
//                 className="border-2 border-white text-white hover:bg-white hover:text-emerald-600 px-8 py-3 rounded-lg font-semibold transition-colors duration-200"
//               >
//                 Login
//               </Link>
//             </div>
//           ) : (
//             <Link
//               to="/dashboard"
//               className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-3 rounded-lg font-semibold transition-colors duration-200 inline-flex items-center"
//             >
//               Start Shopping
//               <ArrowRight className="ml-2 h-5 w-5" />
//             </Link>
//           )}
//         </div>
//       </section>
//     </div>
//   );
// };

// export default HomePage;





import React from "react";
import { Link } from "react-router-dom";
import { ArrowRight, Star, Clock, Truck, Shield } from "lucide-react";
import { useAuth } from "../contexts/AuthContext";
import { useCart } from "../contexts/CartContext";

const HomePage: React.FC = () => {
  const { user } = useAuth();
  const { addToCart } = useCart();

  const categories = [
    {
      name: "Variety spices and herbs",
      image:
        "https://as2.ftcdn.net/v2/jpg/02/89/44/67/1000_F_289446727_vRX6ctHc8dkaeT0zcKnHSu2w5TWOVtJH.jpg",
      count: "120+ Items",
    },
    {
      name: "Cooking Oil",
      image: "https://images.dealshare.in/1757134648956CookingOil.png?tr=f-webp",
      count: "95+ Items",
    },
    {
      name: "Sugar, Salt & Jaggery",
      image:
        "https://images.dealshare.in/1757134885382Sugar,Salt&Jaggery.png?tr=f-webp",
      count: "80+ Items",
    },
    {
      name: "Flours & Grains",
      image:
        "https://images.dealshare.in/1757134734804Flours&Grains.png?tr=f-webp",
      count: "65+ Items",
    },
    {
      name: "Rice & Rice Products",
      image:
        "https://images.dealshare.in/1757134867440Rice&RiceProducts.png?tr=f-webp",
      count: "45+ Items",
    },
    {
      name: "Dals & Pulses",
      image:
        "https://images.dealshare.in/1757134671179Dals&Pulses.png?tr=f-webp",
      count: "85+ Items",
    },
    {
      name: "Ghee & Vanaspati",
      image:
        "https://images.dealshare.in/1757072788411Ghee&Vanaspati.png?tr=f-webp",
      count: "85+ Items",
    },
    {
      name: "Dry Fruits & Nuts",
      image: "https://images.dealshare.in/1757134697555DryFruits.png?tr=f-webp",
      count: "85+ Items",
    },
  ];

  const featuredProducts = [
    {
      id: "1",
      name: "Chambal",
      price: 128,
      image:
        "https://media.dealshare.in/img/offer/1751009426619:0C931BD190_1.png?tr=f-webp",
      rating: 4.8,
      discount: 15,
    },
    {
      id: "2",
      name: "Chambal 5L",
      price: 665,
      image:
        "https://media.dealshare.in/img/offer/1742374265320:0A6256F2B0_1.png?tr=f-webp",
      rating: 4.9,
      discount: 10,
    },
    {
      id: "3",
      name: "Amul Ghee 1L",
      price: 577,
      image:
        "https://media.dealshare.in/img/offer/1751010093034:789AFF118B_1.png?tr=f-webp",
      rating: 4.7,
      discount: 20,
    },
    {
      id: "4",
      name: "Krishna Ghee 1L",
      price: 575,
      image:
        "https://media.dealshare.in/img/offer/1751010093116:685ACFE4F3_1.png?tr=f-webp",
      rating: 4.6,
      discount: 5,
    },
    {
      id: "5",
      name: "Krishna Ghee 500ml",
      price: 296,
      image:
        "https://media.dealshare.in/img/offer/1751010093116:685ACFE4F3_1.png?tr=f-webp",
      rating: 4.6,
      discount: 5,
    },
    {
      id: '6',
      name: 'Amul Ghee 500ML',
      price: 300,
      image: 'https://media.dealshare.in/img/offer/1751010093034:789AFF118B_1.png?tr=f-webp',
      rating: 4.7,
      discount: 20
    },
    {
      id: '7',
      name: 'Saras Ghee 500ML',
      price: 270,
      image: 'https://media.dealshare.in/img/offer/1743008268081:D617F52F15_1.png?tr=f-webp',
      rating: 4.7,
      discount: 20
    },
    {
      id: '8',
      name: 'Saras Ghee 1L',
      price: 515,
      image: 'https://media.dealshare.in/img/offer/1743008268081:D617F52F15_1.png?tr=f-webp',
      rating: 4.7,
      discount: 20
    },
    {
      id: '9',
      name: 'Oswal Soap',
      price: 84,
      image: 'https://media.dealshare.in/img/offer/1751011291631:C89837D20A_1.png?tr=f-webp',
      rating: 4.7,
      discount: 20
    },
    {
      id: '10',
      name: 'Taaza Tea 1KG',
      price: 189,
      image: 'https://media.dealshare.in/img/offer/1742374266672:642868CAF9_1.png?tr=f-webp',
      rating: 4.7,
      discount: 20
    },
    {
      id: '11',
      name: 'Taaza Tea 250GG',
      price: 57,
      image: 'https://media.dealshare.in/img/offer/1742374266672:642868CAF9_1.png?tr=f-webp',
      rating: 4.7,
      discount: 20
    },
    {
      id: '12',
      name: 'Tata Premium Tea - 1 Kg',
      price: 489,
      image: "https://media.dealshare.in/img/offer/1751011291220:873D476C94_1.png?tr=f-webp",
      rating: 4.7,
      discount: 20
    },
    {
      id: '13',
      name: 'Horlicks Chocolate Jar - 1 Kg',
      price: 349,
      image: 'https://media.dealshare.in/img/offer/1751009426532:0B2DAFD45F_1.png?tr=f-webp',
      rating: 4.7,
      discount: 20
    },
    {
      id: '14',
      name: 'Laxmi Bhog Atta - 10 Kg',
      price: 399,
      image: 'https://media.dealshare.in/img/offer/1751010093129:4855D2F2E0_1.png?tr=f-webp',
      rating: 4.7,
      discount: 20
    },
    {
      id: '15',
      name: 'Laxmi Bhog Atta - 5 Kg',
      price: 202,
      image: 'https://media.dealshare.in/img/offer/1751010093129:4855D2F2E0_1.png?tr=f-webp',
      rating: 4.7,
      discount: 20
    },
    {
      id: '15',
      name: 'Laxmi Bhog Suji - 1 Kg',
      price: 50,
      image: 'https://media.dealshare.in/img/offer/1741596846075:8C374CA701_1.png',
      rating: 4.7,
      discount: 20
    },
    {
      id: '16',
      name: 'Laxmi Bhog Suji - 500 gm',
      price: 28,
      image: 'https://media.dealshare.in/img/offer/1741596846075:8C374CA701_1.png',
      rating: 4.7,
      discount: 20
    },
    {
      id: '17',
      name: 'Laxmi Bhog Madia - 500 gm',
      price: 25,
      image: 'https://media.dealshare.in/img/offer/1742210634663:103DBD5C59_1.png?tr=f-webp',
      rating: 4.7,
      discount: 20
    },
    {
      id: '19',
      name: 'Laxmi Bhog Madia - 1kg',
      price: 50,
      image: 'https://media.dealshare.in/img/offer/1742210634663:103DBD5C59_1.png?tr=f-webp',
      rating: 4.7,
      discount: 20
    },
    {
      id: '20',
      name: 'Laxmi Bhog Basen - 1kg',
      price: 95,
      image: 'https://media.dealshare.in/img/offer/A3D32C36E2_1.webp?tr=f-webp',
      rating: 4.7,
      discount: 20
    },
    {
      id: '21',
      name: 'Laxmi Bhog Basen - 500 gm',
      price: 50,
      image: 'https://media.dealshare.in/img/offer/A3D32C36E2_1.webp?tr=f-webp',
      rating: 4.7,
      discount: 20
    },
    {
      id: '22',
      name: 'Laxmi Bhog Dalia - 500 gm',
      price: 32,
      image: 'https://images.dealshare.in/1754456901237:67B545507D_1.png?tr=f-webp',
      rating: 4.7,
      discount: 20
    },
    {
      id: '23',
      name: 'Laxmi Bhog Dalia - 1 kg',
      price: 62,
      image: 'https://images.dealshare.in/1754456901237:67B545507D_1.png?tr=f-webp',
      rating: 4.7,
      discount: 20
    },
    {
      id: '24',
      name: 'Fortune Mogra Basmati Rice - 5 Kg',
      price: 312,
      image: 'https://media.dealshare.in/img/offer/F870A3D320_1.webp?tr=f-webp',
      rating: 4.7,
      discount: 20
    },
    {
      id: '25',
      name: 'Fortune Mogra Basmati Rice - 10 Kg',
      price: 612,
      image: 'https://media.dealshare.in/img/offer/F870A3D320_1.webp?tr=f-webp',
      rating: 4.7,
      discount: 20
    },
    {
      id: '26',
      name: 'Fortune Mini Mogra Basmati Rice - 5 Kg',
      price: 271,
      image: 'https://images.dealshare.in/1753957333960:F7BFF5F2FD_1.png?tr=f-webp',
      rating: 4.7,
      discount: 20
    },
    {
      id: '27',
      name: 'Fortune Mini Mogra Basmati Rice - 10 Kg',
      price: 550,
      image: 'https://images.dealshare.in/1753957333960:F7BFF5F2FD_1.png?tr=f-webp',
      rating: 4.7,
      discount: 20
    },
    {
      id: '28',
      name: 'Fortune Rice Bran Health Oil (pouch) - 825 Gm',
      price: 157,
      image: 'https://images.dealshare.in/1761135461094:B876140DED_1.png?tr=f-webp',
      rating: 4.7,
      discount: 20
    },
    {
      id: '29',
      name: 'Fortune Sunlite Refined Sunflower Oil - 4.35 Kg',
      price: 825,
      image: 'https://media.dealshare.in/img/offer/1746535993492:98F2096C64_1.png?tr=f-webp',
      rating: 4.7,
      discount: 20
    },
    {
      id: '30',
      name: 'Fortune Rozana Gold Basmati Rice - 1 Kg',
      price: 89,
      image: 'https://images.dealshare.in/1753957336146:YC8525AAA2_1.png?tr=f-webp',
      rating: 4.7,
      discount: 20
    },
    {
      id: '31',
      name: 'Fortune Sun Lite Refined Sunflower Oil - 800 Gm',
      price: 162,
      image: 'https://media.dealshare.in/img/offer/1745846109567:B11DBC1F33_1.png?tr=f-webp',
      rating: 4.7,
      discount: 20
    },
    {
      id: '32',
      name: 'Fortune Filtered Groundnut Oil - 870 Gm',
      price: 173,
      image: 'https://media.dealshare.in/img/offer/1738240174680:FE8CD2DFBA_1.webp?tr=f-webp',
      rating: 4.7,
      discount: 20
    },
    {
      id: '33',
      name: 'Fortune Rozana Gold Basmati Rice - 5 Kg',
      price: 424,
      image: 'https://images.dealshare.in/1753957336146:YC8525AAA2_1.png?tr=f-webp',
      rating: 4.7,
      discount: 20
    },
    {
      id: '34',
      name: 'Fortune Rice Bran Health Oil (Jar) - 4.35 Kg',
      price: 806,
      image: 'https://media.dealshare.in/img/offer/1743833707913:51E3B2B0FD_1.png?tr=f-webp',
      rating: 4.7,
      discount: 20
    },
    {
      id: '35',
      name: 'Fortune Filtered Groundnut Oil - 4.35 Kg',
      price: 985,
      image: 'https://media.dealshare.in/img/offer/1724683332136:190A21737F_1.webp?tr=f-webp',
      rating: 4.7,
      discount: 20
    },
    {
      id: '36',
      name: 'Fortune Chakki Fresh Atta - 10 Kg',
      price: 410,
      image: 'https://media.dealshare.in/img/offer/1742900595676:4C1C32FFD0_1.png?tr=f-webp',
      rating: 4.7,
      discount: 20
    },
    {
      id: '37',
      name: 'Fortune Rozana Super Basmati Rice - 1 Kg',
      price: 65,
      image: 'https://images.dealshare.in/1753957333960:D55801E0DE_1.png?tr=f-webp',
      rating: 4.7,
      discount: 20
    },
    {
      id: '38',
      name: 'Fortune Rozana Super Basmati Rice - 5 Kg',
      price: 312,
      image: 'https://images.dealshare.in/1753957333960:D55801E0DE_1.png?tr=f-webp',
      rating: 4.7,
      discount: 20
    },
    {
      id: '39',
      name: 'Fortune Refined Soyabean Oil - 4.35 Kg',
      price: 775,
      image: 'https://media.dealshare.in/img/offer/1751011292010:DCC51871CA_1.png?tr=f-webp',
      rating: 4.7,
      discount: 20
    },
    {
      id: '40',
      name: 'Fortune Chakki Fresh Atta - 5 Kg',
      price: 225,
      image: 'https://media.dealshare.in/img/offer/1742900595676:4C1C32FFD0_1.png?tr=f-webp',
      rating: 4.7,
      discount: 20
    },
    {
      id: '41',
      name: 'Fortune Biryani Special Basmati Rice - 1 Kg',
      price: 177,
      image: 'https://images.dealshare.in/1753957333066:5066BCD15C_1.png?tr=f-webp',
      rating: 4.7,
      discount: 20
    },
    {
      id: '42',
      name: 'Tata Agni Tea - 1 Kg',
      price: 215,
      image: 'https://media.dealshare.in/img/offer/1751011291023:8E6B56F8A4_1.png?tr=f-webp',
      rating: 4.7,
      discount: 20
    },
    {
      id: '43',
      name: 'Tata Agni Elaichi Tea - 250 Gm',
      price: 90,
      image: 'https://media.dealshare.in/img/offer/18F84CBFC3_1.webp?tr=f-webp',
      rating: 4.7,
      discount: 20
    },
    {
      id: '44',
      name: 'Tata Tea Agni - 1.5 Kg',
      price: 270,
      image: 'https://media.dealshare.in/img/offer/1751011291018:8FA29DE506_1.png?tr=f-webp',
      rating: 4.7,
      discount: 20
    },
    {
      id: '45',
      name: 'Tata Tea Agni Elaichi Chai - 1 Kg',
      price: 301,
      image: 'https://images.dealshare.in/175749485302300978B3B6F_1.png?tr=f-webp',
      rating: 4.7,
      discount: 20
    },
    {
      id: '46',
      name: 'Tata Agni Tea - 250 Gm',
      price: 55,
      image: 'https://media.dealshare.in/img/offer/1726636263702:6BA1F7CE61_1.webp?tr=f-webp',
      rating: 4.7,
      discount: 20
    },
    {
      id: '47',
      name: 'Cadbury Bournvita Chocolate (Pouch) - 1 Kg',
      price: 337,
      image: 'https://media.dealshare.in/img/offer/1751009429403:3BAE09ED52_1.png?tr=f-webp',
      rating: 4.7,
      discount: 20
    },
    {
      id: '48',
      name: 'Tata Tea Gold - 500 Gm',
      price: 282,
      image: 'https://media.dealshare.in/img/offer/71AFB1D215_1.webp?tr=f-webp',
      rating: 4.7,
      discount: 20
    },
    {
      id: '49',
      name: 'Red Label Tea - 1 Kg',
      price: 419,
      image: 'https://media.dealshare.in/img/offer/71AFB1D215_1.webp?tr=f-webp',
      rating: 4.7,
      discount: 20
    },
    {
      id: '50',
      name: 'Surf Excel Easy Wash Detergent Powder - 7 Kg',
      price: 665,
      image: 'https://media.dealshare.in/img/offer/1751011292213:EDDA0E0DEC_1.png?tr=f-webp',
      rating: 4.7,
      discount: 20
    }
    
  ];

  const features = [
    {
      icon: <Clock className="h-6 w-6" />,
      title: "Fast Delivery",
      description: "Get your groceries delivered within 30 minutes",
    },
    {
      icon: <Shield className="h-6 w-6" />,
      title: "Quality Guaranteed",
      description: "Fresh products with 100% quality assurance",
    },
    {
      icon: <Truck className="h-6 w-6" />,
      title: "Free Delivery",
      description: "Free delivery on orders above ₹500",
    },
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-emerald-600 via-emerald-700 to-emerald-800 text-white">
        <div className="absolute inset-0 bg-black opacity-10"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <h1 className="text-4xl md:text-6xl font-bold leading-tight">
                Fresh Groceries
                <span className="text-orange-400"> Delivered</span>
                <br />To Your Door
              </h1>
              <p className="text-xl text-emerald-100 max-w-lg">
                Get the freshest groceries delivered to your doorstep in
                minutes.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                {!user ? (
                  <>
                    <Link
                      to="/signup"
                      className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-3 rounded-lg font-semibold flex items-center justify-center"
                    >
                      Get Started <ArrowRight className="ml-2 h-5 w-5" />
                    </Link>
                    <Link
                      to="/dashboard"
                      className="border-2 border-white text-white hover:bg-white hover:text-emerald-600 px-8 py-3 rounded-lg font-semibold flex items-center justify-center"
                    >
                      Browse Products
                    </Link>
                  </>
                ) : (
                  <Link
                    to="/dashboard"
                    className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-3 rounded-lg font-semibold flex items-center justify-center"
                  >
                    Start Shopping <ArrowRight className="ml-2 h-5 w-5" />
                  </Link>
                )}
              </div>
            </div>

            <div className="relative">
              <img
                src="https://as1.ftcdn.net/v2/jpg/16/29/70/80/1000_F_1629708072_5C2KrBU5mrGky8kKFB3Ro96MN06sNQmy.jpg"
                alt="Fresh groceries"
                className="rounded-2xl shadow-2xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {features.map((feature, i) => (
              <div key={i} className="text-center space-y-4">
                <div className="bg-emerald-100 text-emerald-600 w-16 h-16 rounded-full flex items-center justify-center mx-auto">
                  {feature.icon}
                </div>
                <h3 className="text-xl font-semibold text-gray-900">
                  {feature.title}
                </h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Featured Products
            </h2>
            <p className="text-gray-600">
              Best deals and top quality products
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {featuredProducts.map((product) => (
              <div
                key={product.id}
                className="group bg-white rounded-xl shadow-sm hover:shadow-md transition overflow-hidden"
              >
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-200"
                />
                <div className="p-4">
                  <h3 className="font-semibold text-gray-900 mb-1">
                    {product.name}
                  </h3>
                  <div className="flex items-center mb-2">
                    <Star className="h-4 w-4 text-yellow-400 fill-current" />
                    <span className="text-sm text-gray-600 ml-1">
                      {product.rating}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-lg font-bold text-emerald-600">
                      ₹{product.price}
                    </span>

                    {/* 👇 Updated Link sends full product data */}
                    <Link
                      to={`/products/${product.id}`}
                      state={{ product }}
                      className="bg-emerald-600 text-white px-4 py-2 rounded-lg hover:bg-emerald-700 transition-colors duration-200"
                    >
                      View Details
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;
