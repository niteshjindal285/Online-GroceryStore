// import React, { useState } from 'react';
// import { useParams, useNavigate } from 'react-router-dom';
// import { Star, Plus, Minus, ShoppingCart, ArrowLeft } from 'lucide-react';
// import { useCart } from '../contexts/CartContext';

// const ProductDetail: React.FC = () => {
//   const { id } = useParams<{ id: string }>();
//   const navigate = useNavigate();
//   const { addToCart } = useCart();
//   const [quantity, setQuantity] = useState(1);

//   // Mock product data - in real app, this would come from an API
//   const product = {
//     id: id || '1',
//     name: 'Chambal',
//     price: 128,
//     image: 'https://media.dealshare.in/img/offer/1751009426619:0C931BD190_1.png?tr=f-webp',
//     category: 'Cooking Oil',
//     rating: 4.8,
//     reviewCount: 127,
//     inStock: true,
//     description: 'Premium organic bananas sourced from sustainable farms. Perfect for smoothies, baking, or enjoying as a healthy snack. Rich in potassium, vitamin B6, and dietary fiber.',
//     nutritionalInfo: {
//       calories: 89,
//       protein: '1.1g',
//       carbs: '22.8g',
//       fat: '0.3g',
//       fiber: '2.6g'
//     },
//     features: [
//       'Certified Organic',
//       'Rich in Potassium',
//       'Natural Energy Source',
//       'Supports Heart Health',
//       'Gluten-Free',
//       'Vegan Friendly'
//     ]
//   };

//   const handleAddToCart = () => {
//     for (let i = 0; i < quantity; i++) {
//       addToCart({
//         id: product.id,
//         name: product.name,
//         price: product.price,
//         image: product.image,
//         category: product.category
//       });
//     }
//   };

//   return (
//     <div className="min-h-screen bg-gray-50">
//       <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
//         {/* Back Button */}
//         <button
//           onClick={() => navigate('/dashboard')}
//           className="flex items-center text-gray-600 hover:text-gray-900 mb-6 transition-colors duration-200"
//         >
//           <ArrowLeft className="h-5 w-5 mr-2" />
//           Back to Products
//         </button>

//         <div className="bg-white rounded-lg shadow-sm overflow-hidden">
//           <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 p-8">
//             {/* Product Image */}
//             <div className="aspect-w-1 aspect-h-1">
//               <img
//                 src={product.image}
//                 alt={product.name}
//                 className="w-full h-96 object-cover rounded-lg"
//               />
//             </div>

//             {/* Product Info */}
//             <div className="space-y-6">
//               <div>
//                 <h1 className="text-3xl font-bold text-gray-900 mb-2">{product.name}</h1>
//                 <div className="flex items-center mb-4">
//                   <div className="flex items-center">
//                     {[...Array(5)].map((_, i) => (
//                       <Star
//                         key={i}
//                         className={`h-5 w-5 ${
//                           i < Math.floor(product.rating) ? 'text-yellow-400 fill-current' : 'text-gray-300'
//                         }`}
//                       />
//                     ))}
//                   </div>
//                   <span className="ml-2 text-gray-600">
//                     {product.rating} ({product.reviewCount} reviews)
//                   </span>
//                 </div>
//                 <p className="text-gray-600 leading-relaxed">{product.description}</p>
//               </div>

//               {/* Price and Stock */}
//               <div className="border-t border-gray-200 pt-6">
//                 <div className="flex items-center justify-between mb-4">
//                   <span className="text-3xl font-bold text-emerald-600">${product.price}</span>
//                   <span className={`px-3 py-1 rounded-full text-sm ${
//                     product.inStock ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
//                   }`}>
//                     {product.inStock ? 'In Stock' : 'Out of Stock'}
//                   </span>
//                 </div>

//                 {/* Quantity Selector */}
//                 <div className="flex items-center space-x-4 mb-6">
//                   <span className="text-gray-700 font-medium">Quantity:</span>
//                   <div className="flex items-center border border-gray-300 rounded-lg">
//                     <button
//                       onClick={() => setQuantity(Math.max(1, quantity - 1))}
//                       className="p-2 hover:bg-gray-100 transition-colors duration-200"
//                     >
//                       <Minus className="h-4 w-4" />
//                     </button>
//                     <span className="px-4 py-2 text-lg font-semibold">{quantity}</span>
//                     <button
//                       onClick={() => setQuantity(quantity + 1)}
//                       className="p-2 hover:bg-gray-100 transition-colors duration-200"
//                     >
//                       <Plus className="h-4 w-4" />
//                     </button>
//                   </div>
//                 </div>

//                 {/* Add to Cart Button */}
//                 <button
//                   onClick={handleAddToCart}
//                   disabled={!product.inStock}
//                   className="w-full bg-emerald-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-emerald-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors duration-200 flex items-center justify-center"
//                 >
//                   <ShoppingCart className="h-5 w-5 mr-2" />
//                   Add to Cart
//                 </button>
//               </div>

//               {/* Features */}
//               <div className="border-t border-gray-200 pt-6">
//                 <h3 className="text-lg font-semibold text-gray-900 mb-3">Features</h3>
//                 <div className="grid grid-cols-2 gap-2">
//                   {product.features.map((feature, index) => (
//                     <div key={index} className="flex items-center">
//                       <div className="w-2 h-2 bg-emerald-600 rounded-full mr-2"></div>
//                       <span className="text-gray-700 text-sm">{feature}</span>
//                     </div>
//                   ))}
//                 </div>
//               </div>
//             </div>
//           </div>

//           {/* Nutritional Information */}
//           <div className="border-t border-gray-200 p-8">
//             <h3 className="text-lg font-semibold text-gray-900 mb-4">Nutritional Information (per 100g)</h3>
//             <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
//               <div className="text-center">
//                 <div className="text-2xl font-bold text-emerald-600">{product.nutritionalInfo.calories}</div>
//                 <div className="text-sm text-gray-600">Calories</div>
//               </div>
//               <div className="text-center">
//                 <div className="text-2xl font-bold text-emerald-600">{product.nutritionalInfo.protein}</div>
//                 <div className="text-sm text-gray-600">Protein</div>
//               </div>
//               <div className="text-center">
//                 <div className="text-2xl font-bold text-emerald-600">{product.nutritionalInfo.carbs}</div>
//                 <div className="text-sm text-gray-600">Carbs</div>
//               </div>
//               <div className="text-center">
//                 <div className="text-2xl font-bold text-emerald-600">{product.nutritionalInfo.fat}</div>
//                 <div className="text-sm text-gray-600">Fat</div>
//               </div>
//               <div className="text-center">
//                 <div className="text-2xl font-bold text-emerald-600">{product.nutritionalInfo.fiber}</div>
//                 <div className="text-sm text-gray-600">Fiber</div>
//               </div>
//             </div>
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default ProductDetail;


import React, { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Star, Plus, Minus, ShoppingCart, ArrowLeft } from "lucide-react";
import { useCart } from "../contexts/CartContext";

const ProductDetail: React.FC = () => {
  const navigate = useNavigate();
  const { addToCart } = useCart();
  const { state } = useLocation(); // 👈 product object will come from HomePage
  const [quantity, setQuantity] = useState(1);

  const product = state?.product;

  if (!product) {
    // If no product was passed (e.g., page refresh), show a fallback
    return (
      <div className="p-8 text-center text-gray-700">
        <p>Product not found.</p>
        <button
          onClick={() => navigate("/")}
          className="text-emerald-600 underline mt-2"
        >
          Back to Home
        </button>
      </div>
    );
  }

  const handleAddToCart = () => {
    addToCart({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      rating: product.rating,
      discount: product.discount,
    });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-6xl mx-auto px-4 py-8">
        <button
          onClick={() => navigate(-1)}
          className="flex items-center text-gray-600 hover:text-gray-900 mb-6 transition-colors duration-200"
        >
          <ArrowLeft className="h-5 w-5 mr-2" />
          Back
        </button>

        <div className="bg-white rounded-lg shadow-sm grid grid-cols-1 md:grid-cols-2 gap-8 p-8">
          <div>
            <img
              src={product.image}
              alt={product.name}
              className="w-full h-96 object-cover rounded-lg"
            />
          </div>

          <div className="space-y-6">
            <h1 className="text-3xl font-bold text-gray-900">{product.name}</h1>
            <div className="flex items-center">
              <Star className="h-5 w-5 text-yellow-400 fill-current" />
              <span className="ml-1 text-gray-600">{product.rating}</span>
            </div>
            <p className="text-gray-600">
              High-quality product at an affordable price.
            </p>

            <div className="flex justify-between items-center border-t border-gray-200 pt-4">
              <span className="text-3xl font-bold text-emerald-600">
                ₹{product.price}
              </span>
              <div className="flex items-center border rounded-lg">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="p-2 hover:bg-gray-100 transition"
                >
                  <Minus className="h-4 w-4" />
                </button>
                <span className="px-4 py-2 text-lg font-semibold">
                  {quantity}
                </span>
                <button
                  onClick={() => setQuantity(quantity + 1)}
                  className="p-2 hover:bg-gray-100 transition"
                >
                  <Plus className="h-4 w-4" />
                </button>
              </div>
            </div>

            <button
              onClick={handleAddToCart}
              className="w-full bg-emerald-600 text-white py-3 rounded-lg font-semibold hover:bg-emerald-700 flex items-center justify-center"
            >
              <ShoppingCart className="h-5 w-5 mr-2" />
              Add to Cart
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetail;
